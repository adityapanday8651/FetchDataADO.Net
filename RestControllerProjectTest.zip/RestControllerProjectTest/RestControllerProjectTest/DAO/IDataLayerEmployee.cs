﻿namespace RestControllerProjectTest.DAO
{
    public interface IDataLayerEmployee
    {
    }
}
