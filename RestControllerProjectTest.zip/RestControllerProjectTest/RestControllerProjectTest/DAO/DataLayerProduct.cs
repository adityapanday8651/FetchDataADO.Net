﻿using System.Data;
using System.Data.SqlClient;

namespace RestControllerProjectTest.DAO
{
    public class DataLayerProduct
    {
        public DataTable GetProducts()
        {

            string connectionString = "Data Source=DESKTOP-42IPC24;Initial Catalog=Sathya;Integrated Security=true";
            string queryString = "SELECT  [Id],[Name],[Price] FROM [ProductDetails]";

            DataSet products = new DataSet();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                try
                {
                    connection.Open();
                    adapter.Fill(products, "Products");
                    connection.Close();
                }
                catch (Exception ex)
                {
                    connection.Close();
                }
            }
            if (products.Tables.Count > 0)
            {
                return products.Tables["Products"];
            }
            return null;
        }
    }
}
