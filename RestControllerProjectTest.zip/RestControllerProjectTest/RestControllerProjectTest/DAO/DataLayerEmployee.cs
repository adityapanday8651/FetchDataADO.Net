﻿using System.Data;
using System.Data.SqlClient;

namespace RestControllerProjectTest.DAO
{
    public class DataLayerEmployee
    {
        public DataTable GetStudents()
        {
            string connectionString = "Data Source=DESKTOP-42IPC24;Initial Catalog=Sathya;Integrated Security=true";
            string queryString = "SELECT [Id],[FirstName],[LastName],[School] FROM [StudentDetails]";
            string queryInsert = "Insert into []";

            DataSet students = new DataSet();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(queryString, connection);
                try
                {
                    connection.Open();
                    adapter.Fill(students, "Students");
                    connection.Close();
                }
                catch (Exception ex)
                {
                    connection.Close();
                }
            }
            if (students.Tables.Count > 0)
            {
                return students.Tables["Students"];
            }
            return null;
        }

        private void InsertData(string connectionString, int Id, string First_Name, string Last_Name, string Company, string Mobile)
        {
            // define INSERT query with parameters
            string query = "INSERT INTO dbo.Table_Emp ( Id,First_Name,Last_Name,Company,Mobile) " +
                           "VALUES (@Id, @First_Name, @Last_Name, @Company, @Mobile) ";

            // create connection and command
            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, cn))
            {
                // define parameters and their values
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = Id;
                cmd.Parameters.Add("@First_Name", SqlDbType.VarChar, 50).Value = First_Name;
                cmd.Parameters.Add("@Last_Name", SqlDbType.VarChar, 50).Value = Last_Name;
                cmd.Parameters.Add("@Company", SqlDbType.VarChar, 50).Value = Company;
                cmd.Parameters.Add("@Mobile", SqlDbType.VarChar, 50).Value = Mobile;

                // open connection, execute INSERT, close connection
                cn.Open();
                cmd.ExecuteNonQuery();
                cn.Close();
            }
        }


    }
}

