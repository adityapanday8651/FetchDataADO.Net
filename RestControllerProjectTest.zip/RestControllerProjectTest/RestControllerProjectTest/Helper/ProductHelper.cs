﻿using RestControllerProjectTest.Models;

namespace RestControllerProjectTest.Helper
{
    public interface ProductHelper
    {
        public List<ProductModel> GetList();
    }
}
