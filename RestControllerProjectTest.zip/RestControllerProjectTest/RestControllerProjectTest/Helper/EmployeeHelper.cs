﻿using RestControllerProjectTest.Models;

namespace RestControllerProjectTest.Helper
{
    public interface EmployeeHelper
    {
        public List<EmployeeModel> GetList();
    }
}
