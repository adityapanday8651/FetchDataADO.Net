﻿using Microsoft.AspNetCore.Mvc;
using RestControllerProjectTest.DAO;
using RestControllerProjectTest.Models;
using RestControllerProjectTest.ModelView;
using System.Data;

namespace RestControllerProjectTest.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index(List<ProductModel> list)
        {
            ProductViewModel viewModel = new ProductViewModel();
            DataLayerProduct dataLayerStudent = new DataLayerProduct();
            DataTable studentsTable = dataLayerStudent.GetProducts();
            List<ProductModel> list1 = new List<ProductModel>();

            ProductModel model = null;
            if (studentsTable != null)
            {

                foreach (DataRow item in studentsTable.Rows)
                {
                    model = new ProductModel();
                    model.Id = Convert.ToInt32(item[0].ToString());
                    model.Name = item[1].ToString();
                    model.Price =Convert.ToDouble(item[2].ToString());
                    list1.Add(model);
                }
            }
            viewModel.listProduct = list1;
            return View(viewModel);
        }
    }
}
