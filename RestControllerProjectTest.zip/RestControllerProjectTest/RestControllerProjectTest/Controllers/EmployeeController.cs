﻿using Microsoft.AspNetCore.Mvc;
using RestControllerProjectTest.DAO;
using RestControllerProjectTest.Models;
using RestControllerProjectTest.ModelView;
using System.Data;

namespace RestControllerProjectTest.Controllers
{
    public class EmployeeController : Controller
    {
        public IActionResult Index(List<EmployeeModel> list)
        {

            EmployeeViewModel viewModel = new EmployeeViewModel();
            DataLayerEmployee dataLayerStudent = new DataLayerEmployee();
            DataTable studentsTable = dataLayerStudent.GetStudents();
            List<EmployeeModel> list1 = new List<EmployeeModel>();

            EmployeeModel model = null;
            if (studentsTable != null)
            {

                foreach (DataRow item in studentsTable.Rows)
                {
                    model = new EmployeeModel();
                    model.Id = Convert.ToInt32(item[0].ToString());
                    model.FirstName = item[1].ToString();
                    model.LastName = item[2].ToString();
                    model.School = item[3].ToString();
                    list1.Add(model);
                }
            }
            viewModel.listEmployee = list1;
            return View(viewModel);
        }



    }
}
