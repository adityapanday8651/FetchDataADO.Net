﻿using RestControllerProjectTest.Models;

namespace RestControllerProjectTest.ModelView
{
    public class ProductViewModel
    {
        public List<ProductModel> listProduct { get; set; }
    }
}
