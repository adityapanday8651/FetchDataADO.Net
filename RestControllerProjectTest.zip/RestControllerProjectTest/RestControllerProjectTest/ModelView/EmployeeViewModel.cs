﻿using RestControllerProjectTest.Models;

namespace RestControllerProjectTest.ModelView
{
    public class EmployeeViewModel
    {
        public List<EmployeeModel> listEmployee { get; set; }
    }
}
