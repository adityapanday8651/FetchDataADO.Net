﻿namespace RestControllerProjectTest.Models
{
    public class ProductModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set;}

        public List<ProductModel> listProduct { get; }

        public ProductModel()
        {
            listProduct = new List<ProductModel>();
        }
    }
}
